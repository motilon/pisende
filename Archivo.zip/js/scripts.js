'use strict';

document.addEventListener('DOMContentLoaded', function () {
    //Iniciamos WOW
    new WOW().init();
});